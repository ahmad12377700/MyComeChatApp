//  ComponentList.swift
//  ios-chat-uikit-app
//  Created by CometChat Inc. on 18/12/19.
//  Copyright © 2020 CometChat Inc. All rights reserved.

import UIKit
import CometChatUIKitSwift
import CometChatSDK

protocol LaunchDelegate {

    ///Chats
    func launchConversationsWithMessages()
    func launchContacts()
    
    /// Calls
    func launchCallButtonComponent()
    func launchCallLogsComponent()
    func launchCallLogsWithDetailsComponent()
    func launchCallLogDetailsComponent()
    func launchCallLogParticipantComponent()
    func launchCallLogRecordingComponent()
    func launchCallLogHistoryComponent()

    ///Users
    func launchUsersWithMessages()
    func launchUsers()
    func launchListItemForUser()
    func launchDetailsForUser()
    
    ///Groups
    func launchGroupsWithMessages()
    func launchGroups()
    func launchListItemForGroup()
    func launchCreateGroup()
    func launchJoinPasswordProtectedGroup()
    func launchViewMembers()
    func launchAddMembers()
    func launchBannedMembers()
    func launchTransferOwnership()
    func launchDetailsForGroup()
    
    ///Messages
    func launchMessages()
    func launchMessageHeader()
    func launchMessageList()
    func launchMessageComposer()
    func launchMessageInformation()
    
    ///Shared
    ///Resources
    func launchSoundManagerComponent()
    func launchThemeComponent()
    func launchLocalizeComponent()
    

    ///View Componensts
    func launchAvatarComponent()
    func launchBadgeCountComponent()
    func launchStatusIndicatorComponent()
    func launchMessageReceiptComponent()
    func launchTextBubbleComponent()
    func launchImageBubbleComponent()
    func launchVideoBubbleComponent()
    func launchAudioBubbleComponent()
    func launchFileBubbleComponent()
    func launchFormBubbleComponent()
    func launchCardBubbleComponent()
    func launchSchedulerComponent()
    func launchMediaRecorderComponent()
    func launchListItem()
    
}

class ComponentList: UIViewController {
    
    //MARK: OUTLETS
    @IBOutlet weak var componentsTable: UITableView!
    
    //MARK: VARIABLES
    var moduleType : moduleType = .chats
    var customData : CustomJSONModel?
    static var launchDelegate : LaunchDelegate?
    
    //MARK: LIFE CYLCE
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        getCustomData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        setUpNavBar()
    }
    
    func setupTableView() {
        componentsTable.separatorStyle = .none
        componentsTable.delegate = self
        componentsTable.dataSource = self
        let UICompoenentCell  = UINib.init(nibName: "UIComponentsCell", bundle: nil)
        componentsTable.register(UICompoenentCell, forCellReuseIdentifier: "uiComponentsCell")
    }
    
    func getCustomData() {
        customData =  JsonDecoding.decodeJsonIntoCodable(jsonString: ModulesJson.jsonString)
        componentsTable.reloadData()
    }
    
    func setUpNavBar() {
        self.navigationItem.title = ""
        let backButton = UIBarButtonItem()
        switch moduleType {
        case .chats:
            backButton.title = "Chats"
        case .users:
            backButton.title = "Users"
        case .groups:
            backButton.title = "Groups"
        case .shared:
            backButton.title = "Shared"
        case .calls:
            backButton.title = "Calls"
        }
        backButton.setTitleTextAttributes([ NSAttributedString.Key.font:  UIFont.boldSystemFont(ofSize: 20)], for: .normal)
        backButton.tintColor = UIColor(named: "label1")
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        self.navigationController?.view.tintColor = UIColor.black
        self.navigationController?.navigationBar.isTranslucent = true
    }
}

extension ComponentList: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        switch moduleType {
        case .chats :
            return 1
        case .groups:
            return customData?.groups.count ?? 0
        case .shared:
            return customData?.shared.count ?? 0
        case .users:
            return customData?.users.count ?? 0
        case .calls:
            return customData?.calls.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch moduleType {
        case .chats :
            return 2
        case .groups:
            return 1
        case .shared:
            return customData?.shared[section].count ?? 0
        case .users:
            return 1
        case .calls:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let componentCell = tableView.dequeueReusableCell(withIdentifier: "uiComponentsCell") as? UIComponentsCell else { fatalError() }
        
        // Switch based on the moduleType
        switch moduleType {
        case .chats:
            // For chats, customize the rows to show specific names for each row
            switch indexPath.row {
            case 0:
                // Set up for "Conversations with Messages"
                componentCell.setUpCell(customData: customData?.chat[indexPath.section] ?? [], indexPath: indexPath)
                componentCell.componentName.text = "Conversations with Messages"  // Set custom title
            case 1:
                // Set up for "Contacts"
                componentCell.setUpCell(customData: customData?.chat[indexPath.section] ?? [], indexPath: indexPath)
                componentCell.componentName.text = "Contacts"  // Set custom title
            default:
                break
            }
        case .groups:
            switch indexPath.row {
            case 0:
                componentCell.setUpCell(customData: customData?.groups[indexPath.section] ?? [], indexPath: indexPath)
                componentCell.componentName.text = "Groups with Messages"  // Set custom title
            default:
                break
            }
            
        case .shared:
            // Handle for Shared section
            componentCell.setUpCell(customData: customData?.shared[indexPath.section] ?? [], indexPath: indexPath)
            
        case .users:
            switch indexPath.row {
            case 0:
                componentCell.setUpCell(customData: customData?.users[indexPath.section] ?? [], indexPath: indexPath)
                componentCell.componentName.text = "Users with Messages"  // Set custom title
            default:
                break
            }
            
        case .calls:
        switch indexPath.row {
        case 0:
            componentCell.setUpCell(customData: customData?.calls[indexPath.section] ?? [], indexPath: indexPath)
            componentCell.componentName.text = "Call Logs"  // Set custom title
        default:
            break
        }
        }
        return componentCell
    }

    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        launchComponent(section: indexPath.section, rowIndex: indexPath.row, moduleType: moduleType)
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header  = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 30))
        let lable = UILabel(frame: CGRect(x: 20, y: 0, width: header.frame.size.width, height: header.frame.size.height - 4))
        lable.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        lable.textColor = .systemGray
        header.addSubview(lable)
        if moduleType == .shared {
            switch section {
            case 0:
                lable.text = "Resources"
            case 1:
                lable.text = "Views"
            default:
                break
            }
        }
        return header
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if moduleType == .shared {
            return 30.0
        } else {
            return CGFloat.leastNonzeroMagnitude
        }
    }
}

///this method is used to launch componenets of the following modules: -
///Chats, Users, Messages, Groups, Shared
extension ComponentList {
    func launchComponent(section : Int , rowIndex: Int , moduleType: moduleType) {
        switch moduleType {
        case .chats:
            switch (section, rowIndex) {
            case (0,0):
                ComponentList.launchDelegate?.launchConversationsWithMessages()
            case (0, 1):
                ComponentList.launchDelegate?.launchContacts()
            default:
                break
            }

            
        case .users:
            switch (section, rowIndex) {
            case (0,0):
                ComponentList.launchDelegate?.launchUsersWithMessages()
            case (_, _):
                break
            }

        case .groups:
            switch (section, rowIndex) {
            case (0,0):
                ComponentList.launchDelegate?.launchGroupsWithMessages()
            case (_, _):
                break
            }
            
        case .shared:
            switch (section, rowIndex) {
            case (0,0):
                ComponentList.launchDelegate?.launchSoundManagerComponent()
            case (0, 1):
                ComponentList.launchDelegate?.launchThemeComponent()
            case (0,2):
                ComponentList.launchDelegate?.launchLocalizeComponent()
                
            case (1,0):
                ComponentList.launchDelegate?.launchAvatarComponent()
            case (1, 1):
                ComponentList.launchDelegate?.launchBadgeCountComponent()
            case (1,2):
                ComponentList.launchDelegate?.launchStatusIndicatorComponent()
            case (1,3):
                ComponentList.launchDelegate?.launchMessageReceiptComponent()
            case (1,4):
                ComponentList.launchDelegate?.launchTextBubbleComponent()
            case (1,5):
                ComponentList.launchDelegate?.launchImageBubbleComponent()
            case (1,6):
                ComponentList.launchDelegate?.launchVideoBubbleComponent()
            case (1,7):
                ComponentList.launchDelegate?.launchAudioBubbleComponent()
            case (1,8):
                ComponentList.launchDelegate?.launchFileBubbleComponent()
            case (1,9):
                ComponentList.launchDelegate?.launchFormBubbleComponent()
            case (1,10):
                ComponentList.launchDelegate?.launchCardBubbleComponent()
            case (1, 11):
                ComponentList.launchDelegate?.launchSchedulerComponent()
            case (1,12):
                ComponentList.launchDelegate?.launchMediaRecorderComponent()
            case (1,13):
                ComponentList.launchDelegate?.launchListItem()
       
            
            case (_, _):
                break
            }
            
        case .calls:
            switch (section, rowIndex) {
            case (0,0):
                ComponentList.launchDelegate?.launchCallLogsComponent()
            case (_, _):
                break
            }
        }
    }
}





