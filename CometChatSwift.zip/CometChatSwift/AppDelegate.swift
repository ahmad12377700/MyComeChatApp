//  AppDelegate.swift
//  Demo
//
//  Created by CometChat Inc. on 16/12/19.
//  Copyright © 2020 CometChat Inc. All rights reserved.
//

import UIKit
import CometChatSDK
import CometChatUIKitSwift

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func randomString(length: Int) -> String {
        let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return String((0..<length).map { _ in letters.randomElement()! })
    }
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        self.initialization()
        
        // Set the default theme
        CometChatTheme.defaultAppearance()
        let palette = Palette()
        palette.set(background: .purple)
        palette.set(accent: .cyan)
        palette.set(primary: .green)
        palette.set(error: .red)
        palette.set(success: .yellow)
        palette.set(secondary: .orange)
        
        let family = CometChatFontFamily(regular: "CourierNewPSMT", medium: "CourierNewPS-BoldMT", bold: "CourierNewPS-BoldMT")
        var typography = Typography()
        typography.overrideFont(family: family)
        
        if CometChat.getLoggedInUser() != nil {
            presentHomeScreen()
        } else {
            presentLoginScreen()
        }
        
        return true
    }
    
    func initialization() {
        if AppConstants.APP_ID.contains("Enter") || AppConstants.APP_ID.isEmpty {
            // Handle unconfigured App ID
            return
        }
        
        let uikitSettings = UIKitSettings()
            .set(appID: AppConstants.APP_ID)
            .set(authKey: AppConstants.AUTH_KEY)
            .set(region: AppConstants.REGION)
            .subscribePresenceForAllUsers()
            .build()
        
        CometChatUIKit.init(uiKitSettings: uikitSettings, result: { result in
            switch result {
            case .success:
                CometChat.setSource(resource: "uikit-v4", platform: "ios", language: "swift")
            case .failure(let error):
                print("Initialization Error: \(error)")
            }
        })
    }

    
    func presentHomeScreen() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let mainVC = storyboard.instantiateViewController(withIdentifier: "home") as! Home
        let navigationController = UINavigationController(rootViewController: mainVC)
        navigationController.modalPresentationStyle = .fullScreen
        navigationController.navigationBar.prefersLargeTitles = true
        
        if #available(iOS 13.0, *) {
            let navBarAppearance = UINavigationBarAppearance()
            navBarAppearance.configureWithOpaqueBackground()
            navBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.label, .font: UIFont.boldSystemFont(ofSize: 20)]
            navBarAppearance.shadowColor = .clear
            navBarAppearance.backgroundColor = .systemGray5
            navigationController.navigationBar.standardAppearance = navBarAppearance
            navigationController.navigationBar.scrollEdgeAppearance = navBarAppearance
            navigationController.navigationBar.isTranslucent = true
        }
        
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()
    }
    
    func presentLoginScreen() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        if let loginVC = storyboard.instantiateViewController(withIdentifier: "Login") as? LoginViewController {
            window?.rootViewController = loginVC
            window?.makeKeyAndVisible()
        } else {
            print("Failed to instantiate LoginViewController")
        }
    }


    
    func logoutAndSwitchUser() {
        CometChat.logout(onSuccess: { _ in // Use `_` to explicitly ignore the argument
            print("Logout successful")
            self.presentLoginScreen()
        }, onError: { error in // Properly use the `error` argument
            print("Logout failed: \(error)")
        })
    }
    func applicationWillResignActive(_ application: UIApplication) {
        CometChat.configureServices(.willResignActive)
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        CometChat.configureServices(.didEnterBackground)
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        CometChat.logout(onSuccess: { _ in // Explicitly ignore the argument
            print("Logout successful on app termination")
        }, onError: { error in // Properly use the `error` argument
            print("Error during app termination logout: \(error)")
        })
    }
}
