//
//  LoginViewController.swift
//  Demo
//
//  Created by YourName on Today's Date.
//

import UIKit
import CometChatSDK

class LoginViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var errorLabel: UILabel!
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    // MARK: - Setup UI
    private func setupUI() {
        errorLabel.isHidden = true
        loginButton.layer.cornerRadius = 8
    }
    
    // MARK: - Actions
    @IBAction func loginButtonTapped(_ sender: UIButton) {
        guard let username = usernameTextField.text, !username.isEmpty,
              let password = passwordTextField.text, !password.isEmpty else {
            showError(message: "Please enter both username and password.")
            return
        }
        
        loginUser(username: username, password: password)
    }
    
    // MARK: - Login Logic
    private func loginUser(username: String, password: String) {
        // Replace with your actual CometChat authentication logic
        CometChat.login(UID: username, apiKey: AppConstants.AUTH_KEY, onSuccess: { [weak self] user in
            print("Login successful for user: \(user.stringValue())")
            DispatchQueue.main.async {
                self?.navigateToHomeScreen()
            }
        }, onError: { [weak self] error in
            print("Login failed with error: \(error.errorDescription)")
            DispatchQueue.main.async {
                self?.showError(message: "Login failed. Please try again.")
            }
        })
    }
    
    // MARK: - Navigation
    private func navigateToHomeScreen() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let homeVC = storyboard.instantiateViewController(withIdentifier: "home") as? Home {
            let navigationController = UINavigationController(rootViewController: homeVC)
            navigationController.modalPresentationStyle = .fullScreen
            self.present(navigationController, animated: true, completion: nil)
        }
    }
    
    // MARK: - Helper Methods
    private func showError(message: String) {
        errorLabel.text = message
        errorLabel.isHidden = false
    }
}

