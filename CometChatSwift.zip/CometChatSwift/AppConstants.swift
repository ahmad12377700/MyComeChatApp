//  AppConstants.swift
 
//  Created by CometChat Inc. on 20/09/19.
//  Copyright ©  2020 CometChat Inc. All rights reserved.

import Foundation
import UIKit

class AppConstants {
    static var APP_ID = "2677356b300f540a"
    static var AUTH_KEY = "35571b7634bb145214b757945002bf4d8cb33f9d"
    static var REGION = "us"
}
